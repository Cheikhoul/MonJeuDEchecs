package plateau;

//import java.util.ArrayList;

public interface Joueur {
	
	public Iterable<Board> nextmoves (Board b);
	//public Board b = new Board();
	
	
	
}
